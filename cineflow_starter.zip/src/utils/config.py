from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "cineflow"
    POSTGRES_USER: str = "cineflow"
    POSTGRES_PASSWORD: str = "cin3flow"
    MONGO_URI: str = "mongodb://cineflow:cineflow@localhost:27017"
    MONGO_DB: str = "cineflow"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
