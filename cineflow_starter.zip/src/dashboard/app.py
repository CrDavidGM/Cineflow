import pandas as pd
import streamlit as st
from sqlalchemy import create_engine
from src.utils.config import settings

st.set_page_config(page_title="CineFlow", layout="wide")

st.title("🎬 CineFlow Dashboard")
st.caption("KPIs de ratings a partir de MovieLens")

url = f"postgresql+psycopg2://{settings.POSTGRES_USER}:{settings.POSTGRES_PASSWORD}@{settings.POSTGRES_HOST}:{settings.POSTGRES_PORT}/{settings.POSTGRES_DB}"
engine = create_engine(url)

@st.cache_data(ttl=60)
def load_top(n: int):
    q = f'''
    SELECT m.title, COUNT(f.user_id) AS ratings, ROUND(AVG(f.rating)::numeric,2) AS avg_rating
    FROM fact_rating f
    JOIN dim_movie m ON m.movie_id = f.movie_id
    GROUP BY m.title
    HAVING COUNT(f.user_id) >= 10
    ORDER BY avg_rating DESC, ratings DESC
    LIMIT {n}
    '''
    return pd.read_sql(q, engine)

n = st.slider("Límite", 5, 50, 15)
df = load_top(n)
st.dataframe(df, use_container_width=True)
st.bar_chart(df.set_index("title")["avg_rating"])
