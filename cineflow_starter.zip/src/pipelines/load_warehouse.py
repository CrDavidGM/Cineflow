"""Transforma datos crudos en Mongo y los carga a Postgres (modelo simple)."""
import pandas as pd
from sqlalchemy import text
from src.storage.mongo_client import get_mongo
from src.storage.postgres_client import get_engine, init_schema

def main():
    # 1) leer raw de Mongo
    _, db = get_mongo()
    ratings = pd.DataFrame(list(db.ratings_raw.find({}, {"_id": 0})))
    movies = pd.DataFrame(list(db.movies_raw.find({}, {"_id": 0})))

    # 2) validaciones mínimas
    assert {"userId","movieId","rating","timestamp"} <= set(ratings.columns), "ratings.csv columnas inválidas"
    assert {"movieId","title","genres"} <= set(movies.columns), "movies.csv columnas inválidas"

    # 3) transformar
    ratings["rating_date"] = pd.to_datetime(ratings["timestamp"], unit="s").dt.date

    # 4) cargar a Postgres
    init_schema()
    engine = get_engine()
    with engine.begin() as conn:
        # dim_movie
        movies[["movieId","title","genres"]].drop_duplicates().rename(columns={
            "movieId":"movie_id"
        }).to_sql("dim_movie", conn, if_exists="append", index=False, method="multi")
        # dim_user
        ratings[["userId"]].drop_duplicates().rename(columns={
            "userId":"user_id"
        }).to_sql("dim_user", conn, if_exists="append", index=False, method="multi")
        # fact_rating
        ratings.rename(columns={
            "userId":"user_id",
            "movieId":"movie_id",
            "timestamp":"rating_ts"
        })[["user_id","movie_id","rating","rating_ts","rating_date"]].to_sql("fact_rating", conn, if_exists="append", index=False, method="multi")

    print("Carga a Postgres completada.")

if __name__ == "__main__":
    main()
