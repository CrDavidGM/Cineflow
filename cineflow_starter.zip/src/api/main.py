from fastapi import FastAPI, Query
from sqlalchemy import text
from src.storage.postgres_client import get_engine

app = FastAPI(title="CineFlow API")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/movies/top")
def top_movies(limit: int = Query(10, ge=1, le=100)):
    engine = get_engine()
    sql = text('''
        SELECT m.movie_id, m.title, m.genres, COUNT(f.user_id) AS ratings, ROUND(AVG(f.rating)::numeric,2) AS avg_rating
        FROM fact_rating f
        JOIN dim_movie m ON m.movie_id = f.movie_id
        GROUP BY m.movie_id, m.title, m.genres
        HAVING COUNT(f.user_id) >= 10
        ORDER BY avg_rating DESC, ratings DESC
        LIMIT :limit
    ''')
    with engine.begin() as conn:
        rows = conn.execute(sql, {"limit": limit}).mappings().all()
    return {"items": [dict(r) for r in rows]}
