from pymongo import MongoClient
from src.utils.config import settings

def get_mongo():
    client = MongoClient(settings.MONGO_URI)
    db = client.get_database(settings.MONGO_DB)
    return client, db
