# CineFlow

Mini pipeline de datos con **MovieLens**: ingesta (raw en Mongo), validación, curado (Postgres), API (FastAPI) y dashboard (Streamlit).

## Quickstart

1) Copia `.env.example` a `.env` y ajusta variables si es necesario.
2) Levanta servicios base:
```bash
docker compose up -d postgres mongo
```
3) (Opcional) Crea entorno local y deps:
```bash
pip install -e .
```
4) Descarga MovieLens 100K y deja CSVs en `data/samples/`:
   - ratings -> `ratings.csv` con columnas: userId,movieId,rating,timestamp
   - movies  -> `movies.csv`  con: movieId,title,genres
5) Ejecuta la primera ingesta a Mongo (raw):
```bash
python -m src.pipelines.ingest_raw
```
6) Carga curada a Postgres:
```bash
python -m src.pipelines.load_warehouse
```
7) API:
```bash
uvicorn src.api.main:app --reload
```
8) Dashboard:
```bash
streamlit run src/dashboard/app.py
```

## Estructura
- `src/pipelines`: ingestión y carga a warehouse
- `src/storage`: clientes Mongo/Postgres
- `src/api`: FastAPI con endpoints de métricas
- `src/dashboard`: Streamlit para KPIs
- `data/samples`: CSVs de entrada
